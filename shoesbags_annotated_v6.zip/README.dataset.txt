# ShoesBags > 2025-01-01 11:20pm
https://universe.roboflow.com/mz-workspace/shoesbags

Provided by a Roboflow user
License: CC BY 4.0

