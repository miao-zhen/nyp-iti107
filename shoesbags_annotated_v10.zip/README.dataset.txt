# ShoesBags > 2025-01-03 9:33am
https://universe.roboflow.com/mz-workspace/shoesbags

Provided by a Roboflow user
License: CC BY 4.0

