# ShoesBags > 2025-01-02 10:53am
https://universe.roboflow.com/mz-workspace/shoesbags

Provided by a Roboflow user
License: CC BY 4.0

