# ShoesBags > 2024-12-30 12:29pm
https://universe.roboflow.com/mz-workspace/shoesbags

Provided by a Roboflow user
License: CC BY 4.0

